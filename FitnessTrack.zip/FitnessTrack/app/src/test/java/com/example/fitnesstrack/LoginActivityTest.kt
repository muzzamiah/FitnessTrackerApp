package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class LoginActivityTest {

    @Test
    fun onCreate() {
    }
}