package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class HealthActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onResume() {
    }

    @Test
    fun onPause() {
    }

    @Test
    fun onSensorChanged() {
    }

    @Test
    fun onAccuracyChanged() {
    }

    @Test
    fun onRequestPermissionsResult() {
    }
}