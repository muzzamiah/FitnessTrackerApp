package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class ProfileActivityTest {

    @Test
    fun onCreate() {
    }
}