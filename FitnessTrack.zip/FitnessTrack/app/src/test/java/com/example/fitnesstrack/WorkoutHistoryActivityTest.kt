package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class WorkoutHistoryActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onSupportNavigateUp() {
    }
}