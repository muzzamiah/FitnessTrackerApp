package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class EditMealActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onOptionsItemSelected() {
    }
}