package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class MealAdapterTest {

    @Test
    fun onCreateViewHolder() {
    }

    @Test
    fun onBindViewHolder() {
    }

    @Test
    fun getItemCount() {
    }

    @Test
    fun updateMeals() {
    }
}