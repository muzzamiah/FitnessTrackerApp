package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class AddMealActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onOptionsItemSelected() {
    }
}