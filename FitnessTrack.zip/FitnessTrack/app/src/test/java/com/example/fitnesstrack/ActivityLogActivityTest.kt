package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class ActivityLogActivityTest {

    @Test
    fun onCreate() {
    }
}