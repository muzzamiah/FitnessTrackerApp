package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class MealSearchActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onCreateOptionsMenu() {
    }

    @Test
    fun onOptionsItemSelected() {
    }
}