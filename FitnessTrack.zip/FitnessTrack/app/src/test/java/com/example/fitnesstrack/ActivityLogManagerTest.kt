package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class ActivityLogManagerTest {

    @Test
    fun saveActivityLog() {
    }

    @Test
    fun getWeeklyLog() {
    }

    @Test
    fun clearWeeklyLog() {
    }

    @Test
    fun getTotalStepsForWeek() {
    }

    @Test
    fun hasLoggedData() {
    }

    @Test
    fun getStepsForDay() {
    }

    @Test
    fun getAllDays() {
    }
}