package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class NutritionActivityTest {

    @Test
    fun onCreate() {
    }

    @Test
    fun onCreateOptionsMenu() {
    }

    @Test
    fun onOptionsItemSelected() {
    }
}