package com.example.fitnesstrack

import org.junit.Assert.*

import org.junit.Test

class MessageAdapterTest {

    @Test
    fun onCreateViewHolder() {
    }

    @Test
    fun onBindViewHolder() {
    }

    @Test
    fun getItemCount() {
    }
}