package com.example.fitnesstrack

// Data class for representing a message
data class Message(
    var message: String,
    var sentBy: String
) {
    companion object {
        const val SENT_BY_ME = "me"   // Sent by the user
        const val SENT_BY_BOT = "bot" // Sent by the bot
    }
}
