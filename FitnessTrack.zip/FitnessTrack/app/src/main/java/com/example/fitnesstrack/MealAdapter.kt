package com.example.fitnesstrack

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MealAdapter(
    private var mealList: MutableList<Meal>,
    private val onEditClick: (Meal) -> Unit,  // onEditClick to edit meal
    private val onDeleteClick: (Meal) -> Unit // onDeleteClick to delete meal
) : RecyclerView.Adapter<MealAdapter.MealViewHolder>() {

    class MealViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val mealName: TextView = view.findViewById(R.id.mealName)
        val mealCalories: TextView = view.findViewById(R.id.mealCalories)
        val mealImage: ImageView = view.findViewById(R.id.mealImage)  // ImageView for meal image
        val editButton: ImageButton = view.findViewById(R.id.editMealButton)
        val deleteButton: ImageButton = view.findViewById(R.id.deleteMealButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_meal, parent, false)
        return MealViewHolder(view)
    }

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val meal = mealList[position]
        holder.mealName.text = meal.strMeal  // Use strMeal from the Meal object
        holder.mealCalories.text = "${meal.strCalories} kcal"  // Use strCalories from the Meal object

        // Load meal image using Glide
        Glide.with(holder.itemView.context)
            .load(meal.strMealThumb)  // Load meal image URL from strMealThumb
            .into(holder.mealImage)

        // Edit meal
        holder.editButton.setOnClickListener {
            onEditClick(meal)
        }

        // Delete meal safely
        holder.deleteButton.setOnClickListener {
            onDeleteClick(meal)
        }
    }

    override fun getItemCount(): Int = mealList.size

    // Function to update the list using DiffUtil for smooth animations
    fun updateMeals(newList: List<Meal>) {
        val diffCallback = object : DiffUtil.Callback() {
            override fun getOldListSize() = mealList.size
            override fun getNewListSize() = newList.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                mealList[oldItemPosition].idMeal == newList[newItemPosition].idMeal  // Compare using idMeal

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                mealList[oldItemPosition] == newList[newItemPosition]
        }

        val diffResult = DiffUtil.calculateDiff(diffCallback)
        mealList = newList.toMutableList()
        diffResult.dispatchUpdatesTo(this)
    }
}
