package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnesstrack.databinding.ActivityNutritionBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NutritionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNutritionBinding
    private val mealList = mutableListOf<Meal>()
    private lateinit var mealAdapter: MealAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNutritionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Set up RecyclerView for meals
        mealAdapter = MealAdapter(mealList,
            onEditClick = { meal -> editMeal(meal) },
            onDeleteClick = { meal -> deleteMeal(meal) }
        )

        binding.nutritionRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.nutritionRecyclerView.adapter = mealAdapter

        // Set up SearchView for searching meals by name
        binding.searchMealInput.addTextChangedListener { text ->
            val query = text.toString()
            if (query.isNotEmpty()) {
                searchMeals(query) // Search meals based on query
            } else {
                mealList.clear() // If search input is empty, clear the list
                mealAdapter.notifyDataSetChanged()
            }
        }

        // Load meals directly from API when activity starts
        searchMeals("")  // Empty query to load meals (or handle as "load all meals")

        // Setup the Bottom Navigation View
        setupBottomNavigationView()
    }

    // Function to search meals by query
    private fun searchMeals(query: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.apiService.searchMeals(query) // API call to search meals
                }

                if (response.meals.isNotEmpty()) {
                    mealList.clear()  // Clear current list before adding new meals
                    mealList.addAll(response.meals)  // Add fetched meals to the list
                    mealAdapter.notifyDataSetChanged()
                } else {
                    Snackbar.make(binding.root, "No meals found for the search query.", Snackbar.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Snackbar.make(binding.root, "Failed to load meals. Please try again.", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    // Edit meal function
    private fun editMeal(meal: Meal) {
        // You can open a new Activity or Dialog for editing the meal details
        val intent = Intent(this, EditMealActivity::class.java).apply {
            putExtra("mealId", meal.idMeal)
            putExtra("mealName", meal.strMeal)
            putExtra("mealCalories", meal.strCalories)
        }
        startActivity(intent)
    }

    // Delete meal function
    private fun deleteMeal(meal: Meal) {
        mealList.remove(meal)
        mealAdapter.notifyDataSetChanged()
        Toast.makeText(this, "Meal deleted", Toast.LENGTH_SHORT).show()
    }

    // Setup Bottom Navigation View
    private fun setupBottomNavigationView() {
        // Set up the BottomNavigationView and handle item selection
        binding.bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Handle Home action
                    navigateToHome()
                    true
                }
                R.id.nav_workout -> {
                    // Handle Workout action
                    navigateToWorkout()
                    true
                }
                R.id.nav_profile -> {
                    // Handle Profile action
                    navigateToProfile()
                    true
                }
                R.id.nav_logout -> {
                    // Handle Logout action
                    logoutUser()
                    true
                }
                else -> false
            }
        }
    }

    // Navigate to Home activity or fragment
    private fun navigateToHome() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    // Navigate to Workout activity or fragment
    private fun navigateToWorkout() {
        val intent = Intent(this, WorkoutActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    // Navigate to Profile activity or fragment
    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    // Create the options menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    // Handle menu item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                logoutUser()  // Call the logout function
                true
            }
            else -> super.onOptionsItemSelected(item)  // Call the parent method for other items
        }
    }

    // Logout Function
    private fun logoutUser() {
        val intent = Intent(this, LogoutActivity::class.java)  // Navigate to LogoutActivity
        startActivity(intent)
        finish()  // Close the current activity
    }
}
