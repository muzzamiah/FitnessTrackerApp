package com.example.fitnesstrack

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var signupTextView: TextView

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize FirebaseAuth here to avoid the UninitializedPropertyAccessException
        firebaseAuth = FirebaseAuth.getInstance()

        // Check if the user is already logged in
        if (isUserLoggedIn()) {
            navigateToOnboarding()
            return
        }

        setContentView(R.layout.activity_login)

        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        signupTextView = findViewById(R.id.signupTextView)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (validateInputs(email, password)) {
                authenticateUser(email, password)
            }
        }

        signupTextView.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }

    // Check if the user is already logged in
    private fun isUserLoggedIn(): Boolean {
        val user = firebaseAuth.currentUser
        return user != null
    }

    // Save user credentials and login state
    private fun saveLoginDetails(email: String) {
        val sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        with(sharedPreferences.edit()) {
            putString("email", email)
            putBoolean("isLoggedIn", true)
            apply()
        }
    }

    // Function to validate inputs
    private fun validateInputs(email: String, password: String): Boolean {
        return when {
            email.isEmpty() -> {
                showToast("Please enter your email")
                false
            }
            password.isEmpty() -> {
                showToast("Please enter your password")
                false
            }
            else -> true
        }
    }

    // Authenticate user with Firebase Authentication
    private fun authenticateUser(email: String, password: String) {
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Save login details
                    saveLoginDetails(email)

                    // Redirect to OnboardingActivity after successful login
                    navigateToOnboarding()
                } else {
                    showToast("Invalid email or password")
                }
            }
    }

    // Navigate to Onboarding Activity
    private fun navigateToOnboarding() {
        val intent = Intent(this, Onboarding::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }

    // Helper function to show a Toast message
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
