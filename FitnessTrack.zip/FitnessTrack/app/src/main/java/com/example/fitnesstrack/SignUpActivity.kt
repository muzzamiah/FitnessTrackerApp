package com.example.fitnesstrack

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ViewBinding setup
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        // Show/hide password toggle
        binding.showPasswordCheckBox.setOnCheckedChangeListener { _, isChecked ->
            val inputType = if (isChecked) android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

            binding.passwordEditText.inputType = inputType
            binding.confirmPasswordEditText.inputType = inputType
        }

        // Set up Date Picker for Date of Birth
        binding.dobEditText.setOnClickListener {
            showDatePicker(binding.dobEditText)
        }

        // Sign Up button click
        binding.signupButton.setOnClickListener {
            val name = binding.nameEditText.text.toString().trim()
            val dob = binding.dobEditText.text.toString().trim()
            val email = binding.emailEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString().trim()
            val confirmPassword = binding.confirmPasswordEditText.text.toString().trim()

            if (validateInput(name, dob, email, password, confirmPassword)) {
                registerUser(email, password)
            }
        }

        // Redirect to Login
        binding.loginTextView.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun validateInput(name: String, dob: String, email: String, password: String, confirmPassword: String): Boolean {
        if (name.isEmpty()) {
            binding.nameEditText.error = "Please enter your name"
            return false
        }
        if (dob.isEmpty()) {
            binding.dobEditText.error = "Please enter your date of birth"
            return false
        }
        if (!isOldEnough(dob)) {
            binding.dobEditText.error = "You must be at least 13 years old to sign up"
            return false
        }
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEditText.error = "Please enter a valid email"
            return false
        }
        if (password.length < 6) {
            binding.passwordEditText.error = "Password must be at least 6 characters"
            return false
        }
        if (password != confirmPassword) {
            binding.confirmPasswordEditText.error = "Passwords do not match"
            return false
        }
        return true
    }

    private fun registerUser(email: String, password: String) {
        firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Successfully registered, now log the user in
                    val user: FirebaseUser? = firebaseAuth.currentUser
                    user?.let {
                        saveUserData(user)
                        showToast("Welcome to FitnessPal, ${user.displayName}!")
                        navigateToOnboarding()
                    }
                } else {
                    showToast("Registration failed: ${task.exception?.message}")
                }
            }
    }

    private fun saveUserData(user: FirebaseUser) {
        // Create a custom UserData object to store in Firebase
        val database = FirebaseDatabase.getInstance().getReference("Users")
        val userId = user.uid
        val userData = UserData(
            name = binding.nameEditText.text.toString(),
            dob = binding.dobEditText.text.toString(),
            email = user.email ?: ""
        )
        database.child(userId).setValue(userData)
    }

    private fun navigateToOnboarding() {
        val intent = Intent(this, Onboarding::class.java)
        startActivity(intent)
        finish()
    }

    private fun showDatePicker(editText: EditText) {
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, dayOfMonth)
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) // Ensuring dd/MM/yyyy format
                editText.setText(dateFormat.format(selectedDate.time))
            },
            calendar.get(Calendar.YEAR) - 13,  // Default to 13 years ago
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.datePicker.maxDate = System.currentTimeMillis() - (13L * 365 * 24 * 60 * 60 * 1000) // Minimum age: 13 years
        datePicker.show()
    }

    private fun isOldEnough(dob: String): Boolean {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) // Ensuring dd/MM/yyyy format
        val birthDate = sdf.parse(dob) ?: return false
        val calendar = Calendar.getInstance()
        calendar.time = birthDate

        val today = Calendar.getInstance()
        val age = today.get(Calendar.YEAR) - calendar.get(Calendar.YEAR)

        return if (today.get(Calendar.MONTH) < calendar.get(Calendar.MONTH) ||
            (today.get(Calendar.MONTH) == calendar.get(Calendar.MONTH) &&
                    today.get(Calendar.DAY_OF_MONTH) < calendar.get(Calendar.DAY_OF_MONTH))) {
            age - 1 >= 13
        } else {
            age >= 13
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

// Custom UserData class to store additional user details
data class UserData(
    val name: String = "",
    val dob: String = "",
    val email: String = ""
)
