package com.example.fitnesstrack

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityEditMealBinding

class EditMealActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditMealBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditMealBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Pre-fill the fields with intent data
        binding.editMealName.setText(intent.getStringExtra("mealName") ?: "")
        binding.editMealCalories.setText(intent.getIntExtra("mealCalories", 0).toString())
        binding.editMealFats.setText(intent.getIntExtra("mealFats", 0).toString())
        binding.editMealCarbs.setText(intent.getIntExtra("mealCarbs", 0).toString())

        binding.saveMealButton.setOnClickListener {
            updateMeal()
        }
    }

    private fun updateMeal() {
        val mealName = binding.editMealName.text.toString().trim()
        val calories = binding.editMealCalories.text.toString().trim().toIntOrNull()
        val fats = binding.editMealFats.text.toString().trim().toIntOrNull()
        val carbs = binding.editMealCarbs.text.toString().trim().toIntOrNull()

        if (mealName.isEmpty()) {
            binding.editMealName.error = "Meal name is required"
            return
        }
        if (calories == null || calories <= 0) {
            binding.editMealCalories.error = "Enter valid calories"
            return
        }
        if (fats == null || fats < 0) {
            binding.editMealFats.error = "Enter valid fats"
            return
        }
        if (carbs == null || carbs < 0) {
            binding.editMealCarbs.error = "Enter valid carbs"
            return
        }

        val resultIntent = Intent().apply {
            putExtra("mealName", mealName)
            putExtra("mealCalories", calories)
            putExtra("mealFats", fats)
            putExtra("mealCarbs", carbs)
        }

        setResult(Activity.RESULT_OK, resultIntent)
        Toast.makeText(this, "Meal updated successfully!", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
