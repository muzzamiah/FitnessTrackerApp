package com.example.fitnesstrack

import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.ByteArrayOutputStream
import java.util.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private var imageUri: Uri? = null

    @RequiresApi(Build.VERSION_CODES.P)
    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { isSuccess ->
            if (isSuccess && imageUri != null) {
                loadAndSaveImage(imageUri!!)
            }
        }

    @RequiresApi(Build.VERSION_CODES.P)
    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                loadAndSaveImage(it)
            }
        }

    @RequiresApi(Build.VERSION_CODES.P)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        setupDropdowns()
        loadUserData()

        binding.dobEditText.setOnClickListener { showDatePicker() }
        binding.updateProfileButton.setOnClickListener { saveUserData() }
        binding.changeProfilePictureButton.setOnClickListener { showProfilePictureOptions() }
        binding.logoutButton.setOnClickListener { showLogoutDialog() }

        // New button listeners for your additional buttons:
        binding.viewProgressButton.setOnClickListener { openFeedback() }
        binding.manageWorkoutsButton.setOnClickListener { openResetPassword() }
        binding.manageNutritionButton.setOnClickListener { openReportProblem() }
        binding.privacyPolicyButton.setOnClickListener { openPrivacyPolicy() }
    }

    private fun setupDropdowns() {
        val genderOptions = listOf("Male", "Female", "Other")
        val activityOptions = listOf("Low", "Moderate", "High")

        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, genderOptions)
        val activityAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, activityOptions)

        binding.genderDropdown.setAdapter(genderAdapter)
        binding.activityDropdown.setAdapter(activityAdapter)
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun loadUserData() {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId).get()
            .addOnSuccessListener { doc ->
                if (doc != null) {
                    binding.nameEditText.setText(doc.getString("name"))
                    binding.dobEditText.setText(doc.getString("dob"))
                    binding.emailEditText.setText(doc.getString("email"))
                    binding.weightEditText.setText(doc.getString("weight"))
                    binding.heightEditText.setText(doc.getString("height"))
                    binding.genderDropdown.setText(doc.getString("gender"), false)
                    binding.activityDropdown.setText(doc.getString("activity"), false)

                    val base64Image = doc.getString("profileImageBase64")
                    if (!base64Image.isNullOrEmpty()) {
                        val imageBytes = Base64.decode(base64Image, Base64.DEFAULT)
                        val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                        binding.profileImageView.setImageBitmap(bitmap)
                    }
                }
            }
    }

    private fun saveUserData() {
        val userId = auth.currentUser?.uid ?: return

        val name = binding.nameEditText.text.toString().trim()
        val dob = binding.dobEditText.text.toString().trim()
        val email = binding.emailEditText.text.toString().trim()
        val weight = binding.weightEditText.text.toString().trim()
        val height = binding.heightEditText.text.toString().trim()
        val gender = binding.genderDropdown.text.toString().trim()
        val activity = binding.activityDropdown.text.toString().trim()

        if (name.isEmpty() || dob.isEmpty() || email.isEmpty() ||
            weight.isEmpty() || height.isEmpty() || gender.isEmpty() || activity.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val userData = hashMapOf(
            "name" to name,
            "dob" to dob,
            "email" to email,
            "weight" to weight,
            "height" to height,
            "gender" to gender,
            "activity" to activity
        )

        db.collection("users").document(userId).update(userData as Map<String, Any>)
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update profile", Toast.LENGTH_SHORT).show()
            }
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun loadAndSaveImage(uri: Uri) {
        try {
            val source = ImageDecoder.createSource(contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source)
            binding.profileImageView.setImageBitmap(bitmap)

            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, byteArrayOutputStream)
            val byteArray = byteArrayOutputStream.toByteArray()
            val base64Image = Base64.encodeToString(byteArray, Base64.DEFAULT)

            val userId = auth.currentUser?.uid ?: return
            db.collection("users").document(userId)
                .update("profileImageBase64", base64Image)
                .addOnSuccessListener {
                    Log.d("ProfileActivity", "Image saved in Firestore")
                }
                .addOnFailureListener {
                    Log.e("ProfileActivity", "Failed to save image: ${it.message}")
                }

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val picker = DatePickerDialog(this, { _, y, m, d ->
            val date = String.format("%02d/%02d/%04d", d, m + 1, y)
            binding.dobEditText.setText(date)
        }, year, month, day)

        picker.show()
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun showProfilePictureOptions() {
        val options = arrayOf("Take a Photo", "Choose from Gallery", "Cancel")
        AlertDialog.Builder(this)
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> openCamera()
                    1 -> openGallery()
                    2 -> dialog.dismiss()
                }
            }
            .show()
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun openCamera() {
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, ContentValues())
        imageUri = uri
        cameraLauncher.launch(imageUri)
    }

    @RequiresApi(Build.VERSION_CODES.P)
    private fun openGallery() {
        galleryLauncher.launch("image/*")
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                // Sign out user if needed
                auth.signOut()
                startActivity(Intent(this, LogoutActivity::class.java))
                finish()
            }
            .setNegativeButton("No", null)
            .show()
    }

    // New functions for your added buttons:

    private fun openFeedback() {
        val intent = Intent(this, FeedbackActivity::class.java)
        startActivity(intent)
    }

    private fun openResetPassword() {
        val intent = Intent(this, ResetPasswordActivity::class.java)
        startActivity(intent)
    }

    private fun openReportProblem() {
        val intent = Intent(this, ReportProblemActivity::class.java)
        startActivity(intent)
    }

    private fun openPrivacyPolicy() {
        val intent = Intent(this, PrivacyActivity::class.java)
        startActivity(intent)
    }

}
