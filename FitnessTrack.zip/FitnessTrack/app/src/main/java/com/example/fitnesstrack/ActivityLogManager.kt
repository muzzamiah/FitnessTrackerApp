package com.example.fitnesstrack

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.*

class ActivityLogManager(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("ActivityLog", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference

    private val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    private fun getCurrentWeekId(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val week = calendar.get(Calendar.WEEK_OF_YEAR)
        return "$year-W$week"
    }

    private fun getDayOfYearFor(dayIndex: Int): Int {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        calendar.add(Calendar.DAY_OF_YEAR, dayIndex)
        return calendar.get(Calendar.DAY_OF_YEAR)
    }

    fun fetchWeeklyLogFromFirebase(onResult: (Map<String, Int>) -> Unit) {
        val userId = auth.currentUser?.uid ?: return
        val resultMap = mutableMapOf<String, Int>()

        var completed = 0
        for (i in 0..6) {
            val dayName = daysOfWeek[i]
            val dayOfYear = getDayOfYearFor(i).toString()

            val ref = database.child("users").child(userId).child("dailySteps").child(dayOfYear)
            ref.child("stepsTaken").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val steps = snapshot.getValue(Int::class.java) ?: 0
                    resultMap[dayName] = steps
                    completed++
                    if (completed == 7) {
                        saveWeeklyLog(resultMap)
                        onResult(resultMap)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    resultMap[dayName] = 0
                    completed++
                    if (completed == 7) {
                        saveWeeklyLog(resultMap)
                        onResult(resultMap)
                    }
                }
            })
        }
    }

    fun saveActivityLog(day: String, steps: Int) {
        if (day !in daysOfWeek) return

        val log = getWeeklyLog().toMutableMap()
        log[day] = steps
        saveWeeklyLog(log)

        val userId = auth.currentUser?.uid ?: return
        val calendar = Calendar.getInstance()
        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR).toString()

        // Save to Realtime Database
        val ref = database.child("users").child(userId).child("dailySteps").child(dayOfYear)
        ref.child("stepsTaken").setValue(steps)

        // Optionally update weekly summary in legacy format
        val weekId = getCurrentWeekId()
        database.child("users").child(userId).child("activityLogs").child(weekId).child(day).setValue(steps)
        database.child("users").child(userId).child("activityLogs").child(weekId).child("Steps").setValue(log.values.sum())
    }

    fun getWeeklyLog(): Map<String, Int> {
        val json = sharedPreferences.getString("weeklyLog", null)
        val type = object : TypeToken<Map<String, Int>>() {}.type
        val savedLog = if (!json.isNullOrEmpty()) gson.fromJson<Map<String, Int>>(json, type) else emptyMap()
        return daysOfWeek.associateWith { savedLog[it] ?: 0 }
    }

    private fun saveWeeklyLog(log: Map<String, Int>) {
        val json = gson.toJson(log)
        sharedPreferences.edit().putString("weeklyLog", json).apply()
    }

    fun clearWeeklyLog() {
        sharedPreferences.edit().remove("weeklyLog").apply()
    }

    fun getTotalStepsForWeek(): Int {
        return getWeeklyLog().values.sum()
    }

    fun hasLoggedData(): Boolean {
        return getWeeklyLog().any { it.value > 0 }
    }

    fun getStepsForDay(day: String): Int {
        return getWeeklyLog()[day] ?: 0
    }

    fun getAllDays(): List<String> = daysOfWeek
}
