package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityProgressBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.progressindicator.LinearProgressIndicator

class ProgressActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProgressBinding
    private val goals = mutableListOf<Goal>()
    private val MAX_GOALS = 4 // Limit the number of goals to 4

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up ViewBinding
        binding = ActivityProgressBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set toolbar
        setSupportActionBar(binding.toolbar)

        // View Workout History button action
        binding.btnViewHistory.setOnClickListener {
            val intent = Intent(this, WorkoutHistoryActivity::class.java)
            startActivity(intent)
        }

        // New Button to Set Goal (Rectangle Button)
        binding.btnSetGoal.setOnClickListener {
            showGoalDialog()
        }

        // Setup Bottom Navigation View
        setupBottomNavigationView()
    }

    // Function to update the UI with goals
    private fun updateGoalsUI() {
        binding.goalsContainer.removeAllViews()
        for (goal in goals) {
            val goalView = createGoalView(goal)
            binding.goalsContainer.addView(goalView)
        }
    }

    // Function to create a goal view dynamically
    private fun createGoalView(goal: Goal): View {
        val goalView = layoutInflater.inflate(R.layout.goal_item, null)
        val progressBar: LinearProgressIndicator = goalView.findViewById(R.id.goalProgressBar)
        val goalName: EditText = goalView.findViewById(R.id.goalName)

        goalName.setText(goal.name)
        progressBar.progress = goal.progress

        // Edit Progress Button
        goalView.findViewById<View>(R.id.btnEditProgress).setOnClickListener {
            showProgressDialog(goal, progressBar)
        }

        // Remove Goal Button
        goalView.findViewById<View>(R.id.btnRemoveGoal).setOnClickListener {
            goals.remove(goal)
            updateGoalsUI() // Update the UI after removal
        }

        return goalView
    }

    // Function to show progress update dialog
    private fun showProgressDialog(goal: Goal, progressBar: LinearProgressIndicator) {
        val progressInput = EditText(this).apply {
            setHint("Enter progress value (0-100)")
            setText(goal.progress.toString())
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Update Progress for ${goal.name}")
            .setView(progressInput)
            .setPositiveButton("Update") { _, _ ->
                val newProgress = progressInput.text.toString().toIntOrNull()
                if (newProgress != null && newProgress in 0..100) {
                    goal.progress = newProgress
                    progressBar.progress = goal.progress // Update the progress bar
                    updateGoalsUI()  // Update the UI after changing progress
                } else {
                    Snackbar.make(binding.root, "Invalid input. Please enter a valid number between 0 and 100.", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Function to show goal setting dialog
    private fun showGoalDialog() {
        if (goals.size >= MAX_GOALS) {
            Snackbar.make(binding.root, "You can only set up to $MAX_GOALS goals.", Snackbar.LENGTH_SHORT).show()
            return
        }

        val goalInput = EditText(this).apply {
            setHint("Enter your fitness goal")
        }

        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(goalInput)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Set Your Goal")
            .setView(dialogView)
            .setPositiveButton("Set Goal") { _, _ ->
                val goalName = goalInput.text.toString()
                if (goalName.isNotEmpty()) {
                    // Check if the goal name already exists
                    if (goals.any { it.name.equals(goalName, ignoreCase = true) }) {
                        Snackbar.make(binding.root, "Goal with this name already exists!", Snackbar.LENGTH_SHORT).show()
                    } else {
                        val newGoal = Goal(goalName, 0) // Default progress to 0
                        goals.add(newGoal)
                        updateGoalsUI()  // Update the UI with new goal
                    }
                } else {
                    Snackbar.make(binding.root, "Please enter a valid goal.", Snackbar.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Setup Bottom Navigation View
    private fun setupBottomNavigationView() {
        binding.bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    navigateToHome()
                    true
                }
                R.id.nav_workout -> {
                    navigateToWorkout()
                    true
                }
                R.id.nav_profile -> {
                    navigateToProfile()
                    true
                }
                R.id.nav_logout -> {
                    logoutUser()
                    true
                }
                else -> false
            }
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    private fun navigateToWorkout() {
        val intent = Intent(this, WorkoutActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                logoutUser()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun logoutUser() {
        val intent = Intent(this, LogoutActivity::class.java)
        startActivity(intent)
        finish()
    }
}

// Goal data class
data class Goal(
    val name: String,
    var progress: Int
)
