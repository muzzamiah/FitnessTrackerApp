package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)  // Make sure this points to your updated XML layout

        // Initialize FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()



        // Find the logout button and set an onClickListener
        val logoutButton: Button = findViewById(R.id.logout_button)
        logoutButton.setOnClickListener {
            logoutUser()
        }

        // Find and set click listeners for the CardViews (buttons)
        val homeCard: CardView = findViewById(R.id.home_card)
        homeCard.setOnClickListener {
            navigateToActivity(HomeActivity::class.java)
        }

        val settingsCard: CardView = findViewById(R.id.settings_card)
        settingsCard.setOnClickListener {
            navigateToActivity(ProfileActivity::class.java)
        }

        val chatbotCard: CardView = findViewById(R.id.chatbot_card)
        chatbotCard.setOnClickListener {
            navigateToActivity(ChatbotActivity::class.java)
        }

        val caloriesCard: CardView = findViewById(R.id.calories_card)
        caloriesCard.setOnClickListener {
            navigateToActivity(NutritionActivity::class.java)
        }

        val healthCard: CardView = findViewById(R.id.health_card)
        healthCard.setOnClickListener {
            navigateToActivity(HealthActivity::class.java)
        }

        val workoutCard: CardView = findViewById(R.id.workout_card)
        workoutCard.setOnClickListener {
            navigateToActivity(WorkoutActivity::class.java)
        }
    }

    // Function to log out user from Firebase and navigate to LoginActivity
    private fun logoutUser() {
        // Sign out from Firebase Authentication
        firebaseAuth.signOut()

        // Show a toast message for confirmation
        showToast("Logged out successfully!")

        // Navigate back to the Login screen
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Close the HomeActivity to prevent going back to it
    }

    // Function to navigate to a specific activity
    private fun navigateToActivity(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        startActivity(intent)
    }

    // Helper function to show a Toast message
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
