package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LogoutActivity : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize FirebaseAuth
        firebaseAuth = FirebaseAuth.getInstance()

        // Log the user out (Firebase sign-out logic)
        logoutUser()

        // After logging out, navigate to the login screen
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Close the current activity
    }

    private fun logoutUser() {
        // Sign out from Firebase Authentication
        firebaseAuth.signOut()

        // Clear session data (SharedPreferences or other session data)
        val sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.clear() // Clear all stored data
        editor.apply()

        // You can show a toast if needed (for debugging purposes)
        Toast.makeText(this, "Logged out successfully!", Toast.LENGTH_SHORT).show()
    }
}
