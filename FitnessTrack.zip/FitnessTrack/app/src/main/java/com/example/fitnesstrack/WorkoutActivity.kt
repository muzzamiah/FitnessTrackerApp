package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnesstrack.databinding.ActivityWorkoutBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class WorkoutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWorkoutBinding
    private lateinit var workoutAdapter: WorkoutAdapter
    private val workouts = mutableListOf(
        Workout("Push-ups", "10 reps"),
        Workout("Squats", "15 reps"),
        Workout("Lunges", "12 reps"),
        Workout("Pull-ups", "10 reps"),
        Workout("Crunches", "20 reps")
    )
    private val completedWorkouts = mutableListOf<Workout>() // Store completed workouts

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityWorkoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup RecyclerView with adapter
        workoutAdapter = WorkoutAdapter(
            workouts,
            ::onWorkoutRemoved,
            ::showEditDialog,
            ::onWorkoutCompleted // ✅ Added Completion Handler
        )

        binding.workoutRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.workoutRecyclerView.adapter = workoutAdapter

        // Navigate to Workout History
        binding.btnWorkoutHistory.setOnClickListener {
            val intent = Intent(this, WorkoutHistoryActivity::class.java)
            // Send completed workouts to WorkoutHistoryActivity
            intent.putParcelableArrayListExtra("completedWorkouts", ArrayList(completedWorkouts))
            startActivity(intent)
        }

        // AI Chatbot Button
        binding.btnAIChatbot.setOnClickListener {
            val intent = Intent(this, ChatbotActivity::class.java)
            startActivity(intent)
        }

        // AI Chatbot Button
        binding.btnHealth.setOnClickListener {
            val intent = Intent(this, HealthActivity::class.java)
            startActivity(intent)
        }

        // Handle Add Workout button click
        binding.btnAddWorkout.setOnClickListener {
            showAddWorkoutDialog()
        }


        // Setup Bottom Navigation View
        val bottomNavView = findViewById<BottomNavigationView>(R.id.bottomNavView)
        bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Navigate to Home Activity
                    val intent = Intent(this, HomeActivity::class.java) // Assuming Home is your home page
                    startActivity(intent)
                    true
                }
                R.id.nav_workout -> {
                    // Do nothing, we're already on the Workout Activity
                    true
                }
                R.id.nav_profile -> {
                    // Navigate to Profile Activity
                    val intent = Intent(this, ProfileActivity::class.java) // Replace with actual ProfileActivity
                    startActivity(intent)
                    true
                }
                R.id.nav_logout -> {
                    // Handle Logout (You can clear session or do whatever is needed here)
                    val intent = Intent(this, LogoutActivity::class.java) // Replace with LoginActivity or logout logic
                    startActivity(intent)
                    finish() // Optionally finish this activity if user logs out
                    true
                }
                else -> false
            }
        }
    }

    // Show a dialog to add a new workout
    private fun showAddWorkoutDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 20)
        }

        val editTextName = EditText(this).apply {
            hint = "Workout Name"
        }

        val editTextReps = EditText(this).apply {
            hint = "Number of Reps"
        }

        layout.apply {
            addView(editTextName)
            addView(editTextReps)
        }

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Add New Workout")
            .setView(layout)
            .setPositiveButton("Add") { _, _ ->
                val name = editTextName.text.toString().trim()
                val reps = editTextReps.text.toString().trim()

                if (name.isNotEmpty() && reps.isNotEmpty()) {
                    val newWorkout = Workout(name, reps)
                    addNewWorkout(newWorkout)
                    Toast.makeText(this, "Workout added!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    // Add a new workout to the list
    private fun addNewWorkout(workout: Workout) {
        workouts.add(workout)
        workoutAdapter.notifyItemInserted(workouts.size - 1)
        binding.workoutRecyclerView.scrollToPosition(workouts.size - 1)
    }

    // Show a dialog to edit the workout
    private fun showEditDialog(workout: Workout, position: Int) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 20)
        }

        val editTextName = EditText(this).apply {
            setText(workout.name)
            hint = "Workout Name"
        }

        val editTextReps = EditText(this).apply {
            setText(workout.reps)
            hint = "Workout Reps"
        }

        layout.apply {
            addView(editTextName)
            addView(editTextReps)
        }

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Edit Workout")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val newName = editTextName.text.toString().trim()
                val newReps = editTextReps.text.toString().trim()

                if (newName.isNotEmpty() && newReps.isNotEmpty()) {
                    if (newName != workout.name || newReps != workout.reps) {
                        val updatedWorkout = Workout(newName, newReps)
                        workoutAdapter.updateWorkout(updatedWorkout, position)
                        Toast.makeText(this, "Workout updated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No changes made", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    // Remove workout when called
    private fun onWorkoutRemoved(workout: Workout, position: Int) {
        if (position >= 0 && position < workouts.size) {
            workouts.removeAt(position)
            workoutAdapter.notifyItemRemoved(position)
            workoutAdapter.notifyItemRangeChanged(position, workouts.size)
            Toast.makeText(this, "${workout.name} removed!", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle Workout Completion
    private fun onWorkoutCompleted(workout: Workout, position: Int) {
        // Add completed workout to the list of completed workouts
        completedWorkouts.add(workout)

        // Remove the completed workout from the current workout list
        workouts.removeAt(position)
        workoutAdapter.notifyItemRemoved(position)
        workoutAdapter.notifyItemRangeChanged(position, workouts.size)

        Toast.makeText(this, "${workout.name} completed!", Toast.LENGTH_SHORT).show()
    }
}
