package com.example.fitnesstrack


import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

object RetrofitClient {
    private const val BASE_URL = "https://www.themealdb.com/" // Use actual API base URL

    val apiService: MealApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create()) // Gson converter for JSON to objects
            .build()
            .create(MealApiService::class.java)
    }
}

interface MealApiService {

    // Fetch meals based on a search query
    @GET("api/json/v1/1/search.php")
    suspend fun searchMeals(
        @Query("s") query: String // Search query (meal name)
    ): MealResponse

    // Fetch meal details by meal ID
    @GET("api/json/v1/1/lookup.php")
    suspend fun getMealDetails(
        @Query("i") mealId: String // Meal ID to get details for
    ): MealResponse
}
