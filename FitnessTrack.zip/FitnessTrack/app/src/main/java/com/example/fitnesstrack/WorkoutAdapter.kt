package com.example.fitnesstrack

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WorkoutAdapter(
    private val workouts: MutableList<Workout>,
    private val onRemoveWorkout: (Workout, Int) -> Unit,
    private val onEditWorkout: (Workout, Int) -> Unit,
    private val onWorkoutCompleted: (Workout, Int) -> Unit
) : RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder>() {

    inner class WorkoutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val workoutName: TextView = itemView.findViewById(R.id.tvWorkoutName)
        val workoutReps: TextView = itemView.findViewById(R.id.tvWorkoutReps)
        val btnEdit: Button = itemView.findViewById(R.id.btnEdit)
        val btnRemove: Button = itemView.findViewById(R.id.btnRemove)
        val btnComplete: Button = itemView.findViewById(R.id.btnComplete) // ✅ Updated ID to match XML

        init {
            btnEdit.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onEditWorkout(workouts[position], position)
                }
            }

            btnRemove.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onRemoveWorkout(workouts[position], position)
                }
            }

            btnComplete.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onWorkoutCompleted(workouts[position], position)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WorkoutViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.workout_item, parent, false)
        return WorkoutViewHolder(view)
    }

    override fun onBindViewHolder(holder: WorkoutViewHolder, position: Int) {
        val workout = workouts[position]
        holder.workoutName.text = workout.name.ifEmpty { "Unnamed Workout" }
        holder.workoutReps.text = workout.reps.ifEmpty { "No reps specified" }
    }

    override fun getItemCount(): Int = workouts.size

    // ✅ Fixed: Implemented updateWorkout method
    fun updateWorkout(workout: Workout, position: Int) {
        if (position in workouts.indices) {
            workouts[position] = workout
            notifyItemChanged(position)
        }
    }
}
