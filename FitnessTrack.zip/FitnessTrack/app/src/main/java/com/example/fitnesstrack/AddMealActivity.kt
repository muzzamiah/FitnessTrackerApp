package com.example.fitnesstrack

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityAddMealBinding

class AddMealActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddMealBinding
    private var isEditing = false
    private var originalMealName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddMealBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        if (intent.hasExtra("mealName") && intent.hasExtra("mealCalories")) {
            isEditing = true
            originalMealName = intent.getStringExtra("mealName")
            val mealCalories = intent.getIntExtra("mealCalories", 0)

            binding.addMealName.setText(originalMealName)
            binding.addMealCalories.setText(mealCalories.toString())
            binding.saveMealButton.text = "Update Meal"
        }

        binding.saveMealButton.setOnClickListener {
            saveMeal()
        }
    }

    private fun saveMeal() {
        val mealName = binding.addMealName.text.toString().trim()
        val caloriesText = binding.addMealCalories.text.toString().trim()
        val fatsText = binding.addMealFats.text.toString().trim()
        val carbsText = binding.addMealCarbs.text.toString().trim()

        if (mealName.isEmpty()) {
            binding.addMealName.error = "Meal name required"
            return
        }

        val calories = caloriesText.toIntOrNull()
        val fats = fatsText.toIntOrNull()
        val carbs = carbsText.toIntOrNull()

        if (calories == null || calories <= 0) {
            binding.addMealCalories.error = "Enter valid calories"
            return
        }
        if (fats == null || fats < 0) {
            binding.addMealFats.error = "Enter valid fats"
            return
        }
        if (carbs == null || carbs < 0) {
            binding.addMealCarbs.error = "Enter valid carbs"
            return
        }

        val resultIntent = Intent().apply {
            putExtra("mealName", mealName)
            putExtra("mealCalories", calories)
            putExtra("mealFats", fats)
            putExtra("mealCarbs", carbs)
        }

        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
