package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.example.fitnesstrack.databinding.ActivityLogBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.*

class ActivityLogActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLogBinding
    private lateinit var logTextView: TextView
    private lateinit var totalStepsTextView: TextView
    private lateinit var logLayout: LinearLayout

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        logTextView = findViewById(R.id.tvLog)
        totalStepsTextView = findViewById(R.id.tvTotalStepsValue)
        logLayout = findViewById(R.id.logLayout)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        fetchActivityLog()
        setupBottomNavigationView()
    }

    private fun fetchActivityLog() {
        val userId = auth.currentUser?.uid ?: return
        val calendar = Calendar.getInstance()

        val weeklyLog = mutableMapOf<String, Int>()
        val startOfWeek = (calendar.clone() as Calendar).apply {
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }

        logLayout.removeAllViews()

        for (i in 0..6) {
            val dayCalendar = (startOfWeek.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
            val dayOfYear = dayCalendar.get(Calendar.DAY_OF_YEAR)
            val dayName = daysOfWeek[i]

            val ref = database.child("users").child(userId).child("dailySteps").child(dayOfYear.toString())

            ref.child("stepsTaken").get().addOnSuccessListener { snapshot ->
                val steps = snapshot.getValue(Int::class.java) ?: 0
                weeklyLog[dayName] = steps
                if (weeklyLog.size == 7) showWeeklyCards(weeklyLog)
            }.addOnFailureListener {
                weeklyLog[dayName] = 0
                if (weeklyLog.size == 7) showWeeklyCards(weeklyLog)
            }
        }
    }

    private fun showWeeklyCards(log: Map<String, Int>) {
        val totalSteps = log.values.sum()
        totalStepsTextView.text = totalSteps.toString()

        log.forEach { (day, steps) ->
            val caloriesBurned = steps * 0.04f

            val cardView = CardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 0, 0, 20) }
                setCardBackgroundColor(ContextCompat.getColor(context, R.color.white))
                radius = 8f
                cardElevation = 4f
            }

            val innerLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(16, 16, 16, 16)
            }

            val dayTextView = TextView(this).apply {
                text = day
                textSize = 18f
                setTextColor(ContextCompat.getColor(context, R.color.dark_blue))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val stepsTextView = TextView(this).apply {
                text = "$steps steps"
                textSize = 16f
                setTextColor(ContextCompat.getColor(context, R.color.blue))
            }

            val caloriesTextView = TextView(this).apply {
                text = "%.2f kcal".format(caloriesBurned)
                textSize = 14f
                setTextColor(ContextCompat.getColor(context, R.color.light_gray))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(8, 0, 0, 0) }
            }

            innerLayout.addView(dayTextView)
            innerLayout.addView(stepsTextView)
            innerLayout.addView(caloriesTextView)

            cardView.addView(innerLayout)
            logLayout.addView(cardView)
        }
    }

    private fun setupBottomNavigationView() {
        binding.bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    navigateTo(HomeActivity::class.java)
                    true
                }
                R.id.nav_workout -> {
                    navigateTo(WorkoutActivity::class.java)
                    true
                }
                R.id.nav_profile -> {
                    navigateTo(ProfileActivity::class.java)
                    true
                }
                R.id.nav_logout -> {
                    logoutUser()
                    true
                }
                else -> false
            }
        }
    }

    private fun navigateTo(destination: Class<*>) {
        val intent = Intent(this, destination)
        startActivity(intent)
        finish()
    }

    private fun logoutUser() {
        auth.signOut()
        navigateTo(LoginActivity::class.java)
    }
}
