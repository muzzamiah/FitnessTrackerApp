package com.example.fitnesstrack

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityReportProblemBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class ReportProblemActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportProblemBinding
    private val firestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportProblemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup toolbar with back arrow
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.reportProblemButton.setOnClickListener {
            val problemText = binding.problemEditText.text.toString().trim()

            if (problemText.isNotEmpty()) {
                val userId = FirebaseAuth.getInstance().currentUser?.uid ?: "anonymous"
                val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

                val reportData = mapOf(
                    "userId" to userId,
                    "problem" to problemText,
                    "timestamp" to timestamp
                )

                firestore.collection("problemReports")
                    .add(reportData)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Problem reported. We’ll look into it!", Toast.LENGTH_SHORT).show()
                        binding.problemEditText.text?.clear()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to submit report. Try again.", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Please describe the issue", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
