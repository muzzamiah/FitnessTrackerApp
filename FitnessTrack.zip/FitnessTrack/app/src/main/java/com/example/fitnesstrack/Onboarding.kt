package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnesstrack.databinding.ActivityOnboardingBinding

class Onboarding : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the layout using ViewBinding
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if onboarding was already completed
        if (isOnboardingComplete()) {
            navigateToHome()
            return
        }

        // Click listener for the button to navigate to Home Screen
        binding.btnHomeScreen.setOnClickListener {
            completeOnboarding()
            navigateToHome()
        }
    }

    // Check if onboarding is already complete
    private fun isOnboardingComplete(): Boolean {
        val sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE)
        return sharedPreferences.getBoolean("isFirstLaunch", false)
    }

    // Mark onboarding as complete in SharedPreferences
    private fun completeOnboarding() {
        val sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE)
        sharedPreferences.edit().apply {
            putBoolean("isFirstLaunch", true) // Set to true to indicate onboarding is done
            apply()
        }
    }

    // Navigate to MainActivity
    private fun navigateToHome() {
        startActivity(Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish() // Close the onboarding activity
    }
}
