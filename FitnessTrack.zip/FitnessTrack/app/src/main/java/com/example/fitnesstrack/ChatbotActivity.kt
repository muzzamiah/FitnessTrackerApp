package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class ChatbotActivity : AppCompatActivity() {

    private lateinit var quoteTextViews: List<TextView>
    private lateinit var refreshButton: Button
    private lateinit var dailyTipTextView: TextView

    private val handler = Handler(Looper.getMainLooper())

    private val motivationalQuotes = listOf(
        "Push harder than yesterday if you want a different tomorrow.",
        "The pain you feel today will be the strength you feel tomorrow.",
        "Fitness is not about being better than someone else, it's about being better than you used to be.",
        "Wake up. Work out. Look hot. Kick ass.",
        "The body achieves what the mind believes.",
        "Sweat is fat crying.",
        "You don't have to be extreme, just consistent.",
        "Discipline is choosing between what you want now and what you want most.",
        "Fall in love with taking care of yourself.",
        "No excuses. Just results."
    )

    private val dailyTips = listOf(
        "💧 Stay hydrated — aim for 8 glasses a day.",
        "🏃‍♂️ 30 minutes of movement improves your mood.",
        "🥗 Don’t skip breakfast — fuel your body!",
        "😴 7–8 hours of sleep is key to recovery.",
        "📵 Put your phone away 1 hour before bed."
    )

    private var lastShownQuotes: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatbot)

        supportActionBar?.title = "Motivation"

        // Bind views
        quoteTextViews = listOf(
            findViewById(R.id.quote1),
            findViewById(R.id.quote2),
            findViewById(R.id.quote3),
            findViewById(R.id.quote4)
        )

        refreshButton = findViewById(R.id.refreshQuotesButton)
        dailyTipTextView = findViewById(R.id.dailyTipText)

        // Manual refresh button
        refreshButton.setOnClickListener {
            updateQuotesWithAnimation()
        }

        // Long click to share quotes
        refreshButton.setOnLongClickListener {
            shareQuotes()
            true
        }

        // Auto-refresh every 30 seconds
        handler.post(object : Runnable {
            override fun run() {
                updateQuotesWithAnimation()
                handler.postDelayed(this, 30000)
            }
        })

        // Initial quote display
        updateQuotesWithAnimation()

        // Set up bottom navigation
        setupBottomNavigationView()
    }

    private fun updateQuotesWithAnimation() {
        val newQuotes = getNewQuotes()
        lastShownQuotes = newQuotes

        quoteTextViews.forEachIndexed { index, textView ->
            textView.text = newQuotes[index]
            animateText(textView)
            applyCardStyle(textView)
        }

        // Update daily tip randomly
        updateDailyTip()
    }

    private fun getNewQuotes(): List<String> {
        var newQuotes: List<String>
        do {
            newQuotes = motivationalQuotes.shuffled().take(4)
        } while (newQuotes == lastShownQuotes)
        return newQuotes
    }

    private fun animateText(view: View) {
        val fadeIn = AlphaAnimation(0f, 1f)
        fadeIn.duration = 500
        view.startAnimation(fadeIn)
    }

    private fun applyCardStyle(textView: TextView) {
        // Style text as card (adjust this to match your actual design or style)
        val textColor = ContextCompat.getColor(this, android.R.color.black)
        textView.setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
        textView.setTextColor(textColor)
        textView.setPadding(32, 24, 32, 24)
        textView.textSize = 16f
        textView.elevation = 8f
        textView.contentDescription = "Motivational Quote: ${textView.text}"
    }

    private fun updateDailyTip() {
        // Show a random daily tip each time the quotes refresh
        val dailyTip = dailyTips.random()
        dailyTipTextView.text = dailyTip
    }

    private fun shareQuotes() {
        val combinedQuotes = quoteTextViews.joinToString("\n\n") { it.text.toString() }

        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, combinedQuotes)
            type = "text/plain"
        }

        startActivity(Intent.createChooser(shareIntent, "Share quotes via"))
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    private fun setupBottomNavigationView() {
        val bottomNavView: BottomNavigationView = findViewById(R.id.bottomNavView)
        bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    navigateToHome()
                    true
                }
                R.id.nav_workout -> {
                    navigateToWorkout()
                    true
                }
                R.id.nav_profile -> {
                    navigateToProfile()
                    true
                }
                R.id.nav_logout -> {
                    logoutUser()
                    true
                }
                else -> false
            }
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    private fun navigateToWorkout() {
        val intent = Intent(this, WorkoutActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    private fun navigateToProfile() {
        val intent = Intent(this, ProfileActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    private fun logoutUser() {
        val intent = Intent(this, LogoutActivity::class.java)
        startActivity(intent)
        finish()  // Finish current activity
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                logoutUser()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
