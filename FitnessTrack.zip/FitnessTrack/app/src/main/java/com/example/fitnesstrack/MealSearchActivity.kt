package com.example.fitnesstrack

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnesstrack.databinding.ActivityMealSearchBinding
import kotlinx.coroutines.launch

class MealSearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMealSearchBinding
    private val mealList = mutableListOf<Meal>()
    private lateinit var mealAdapter: MealAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMealSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up RecyclerView
        mealAdapter = MealAdapter(mealList,
            onEditClick = { meal -> selectMeal(meal) },  // Handle the meal selection
            onDeleteClick = { meal -> }  // You can implement the delete functionality here
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = mealAdapter

        // Handle Search functionality
        binding.searchMealInput.addTextChangedListener { text ->
            val query = text.toString()
            if (query.isNotEmpty()) {
                searchMeals(query)  // Search meals based on query
            } else {
                mealList.clear()  // If no query, clear the meal list
                mealAdapter.notifyDataSetChanged()
            }
        }
    }

    // Search meals based on the query
    private fun searchMeals(query: String) {
        // Use lifecycleScope to call suspend functions within a Coroutine
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.searchMeals(query)
                if (response.meals != null && response.meals.isNotEmpty()) {
                    mealList.clear()  // Clear existing meals
                    mealList.addAll(response.meals)  // Add meals from search result
                    mealAdapter.notifyDataSetChanged()  // Notify adapter to update the UI
                } else {
                    Toast.makeText(
                        this@MealSearchActivity,
                        "No meals found",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MealSearchActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // When a meal is selected, return the meal data to NutritionActivity
    private fun selectMeal(meal: Meal) {
        val resultIntent = Intent().apply {
            putExtra("mealName", meal.strMeal)
            putExtra("mealCalories", meal.strCalories)
        }
        setResult(RESULT_OK, resultIntent)
        finish()  // Close the activity and return to NutritionActivity
    }

    // Create the options menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)  // Inflate the menu
        return true
    }

    // Handle menu item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                logoutUser()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Logout Function
    private fun logoutUser() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
