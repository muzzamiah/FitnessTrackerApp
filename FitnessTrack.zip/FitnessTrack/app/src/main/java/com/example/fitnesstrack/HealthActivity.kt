package com.example.fitnesstrack

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.mikhaellopez.circularprogressbar.CircularProgressBar
import java.util.*

class HealthActivity : AppCompatActivity(), SensorEventListener {

    private var sensor: Sensor? = null
    private var sensorManager: SensorManager? = null
    private lateinit var stepsTextView: TextView
    private lateinit var progressBar: CircularProgressBar
    private lateinit var bottomNavView: BottomNavigationView
    private lateinit var caloriesTextView: TextView
    private lateinit var stepGoalTextView: TextView
    private lateinit var bmiResultTextView: TextView

    private var stepGoal: Float = 2500f
    private val caloriesPerStep = 0.04f

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    private val PERMISSION_REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health)

        supportActionBar?.hide()

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        stepsTextView = findViewById(R.id.tv_stepstaken)
        progressBar = findViewById(R.id.circularProgressBar)
        caloriesTextView = findViewById(R.id.tvCaloriesBurned)
        stepGoalTextView = findViewById(R.id.tvStepGoal)
        bmiResultTextView = findViewById(R.id.tvResult)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        if (sensor == null) {
            Toast.makeText(this, "Step counter sensor not found", Toast.LENGTH_LONG).show()
            return
        }

        bottomNavView = findViewById(R.id.bottomNavView)
        setupBottomNavigationView()

        loadSavedGoal()
        updateGoalDisplay()

        findViewById<Button>(R.id.btnSetGoal).setOnClickListener { showGoalDialog() }
        findViewById<Button>(R.id.btnWorkoutLog).setOnClickListener {
            startActivity(Intent(this, ActivityLogActivity::class.java))
        }
        findViewById<Button>(R.id.btnBMI).setOnClickListener { calculateBMI() }
        findViewById<Button>(R.id.btnResetSteps).setOnClickListener { resetStepCounter() }

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACTIVITY_RECOGNITION),
                PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onResume() {
        super.onResume()
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACTIVITY_RECOGNITION)
            == PackageManager.PERMISSION_GRANTED) {
            sensor?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
            val totalSteps = event.values[0].toInt()
            Log.d("HealthActivity", "Sensor value: $totalSteps")

            val userId = auth.currentUser?.uid ?: return
            val dayKey = getCurrentDayOfYear().toString()
            val prefs = getSharedPreferences("StepPrefs", Context.MODE_PRIVATE)
            val initialStepsKey = "initialSteps_$dayKey"

            var initialSteps = prefs.getInt(initialStepsKey, -1)
            if (initialSteps == -1 || totalSteps < initialSteps) {
                initialSteps = totalSteps
                prefs.edit().putInt(initialStepsKey, initialSteps).apply()
            }

            val stepsToday = totalSteps - initialSteps
            stepsTextView.text = stepsToday.toString()
            updateUI(stepsToday)

            val userStepsRef = database.child("users").child(userId).child("dailySteps").child(dayKey)
            userStepsRef.child("initialSteps").setValue(initialSteps)
            userStepsRef.child("stepsTaken").setValue(stepsToday)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun updateUI(steps: Int) {
        val caloriesBurned = steps * caloriesPerStep
        caloriesTextView.text = "Calories Burned: %.2f".format(caloriesBurned)
        val progress = (steps.toFloat() / stepGoal) * 100
        progressBar.setProgressWithAnimation(progress.coerceAtMost(100f))
    }

    private fun getCurrentDayOfYear(): Int {
        return Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    }

    private fun setupBottomNavigationView() {
        bottomNavView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_workout -> {
                    startActivity(Intent(this, WorkoutActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_logout -> {
                    auth.signOut()
                    startActivity(Intent(this, LogoutActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    private fun saveStepGoal(goal: Float) {
        getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
            .edit().putFloat("stepGoal", goal).apply()
    }

    private fun loadSavedGoal() {
        val prefs = getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        stepGoal = prefs.getFloat("stepGoal", 2500f)
    }

    private fun updateGoalDisplay() {
        stepGoalTextView.text = "Goal: ${stepGoal.toInt()}"
    }

    private fun showGoalDialog() {
        val editText = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "Enter new goal"
        }

        AlertDialog.Builder(this)
            .setTitle("Set New Step Goal")
            .setView(editText)
            .setPositiveButton("Save") { _, _ ->
                val newGoal = editText.text.toString().toFloatOrNull()
                if (newGoal != null && newGoal > 0) {
                    stepGoal = newGoal
                    saveStepGoal(newGoal)
                    updateGoalDisplay()
                } else {
                    Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun calculateBMI() {
        val heightET = findViewById<EditText>(R.id.heightET)
        val weightET = findViewById<EditText>(R.id.weightET)

        val height = heightET.text.toString().toFloatOrNull()
        val weight = weightET.text.toString().toFloatOrNull()

        if (height != null && weight != null && height > 0) {
            val heightInMeters = height / 100
            val bmi = weight / (heightInMeters * heightInMeters)
            bmiResultTextView.text = "Your BMI: %.2f".format(bmi)
        } else {
            Toast.makeText(this, "Please enter valid height and weight", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetStepCounter() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACTIVITY_RECOGNITION)
            == PackageManager.PERMISSION_GRANTED) {

            val resetSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            if (resetSensor == null) {
                Toast.makeText(this, "Step counter sensor not found", Toast.LENGTH_SHORT).show()
                return
            }

            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent?) {
                    val newInitial = event?.values?.get(0)?.toInt() ?: return
                    val dayKey = getCurrentDayOfYear().toString()
                    val prefs = getSharedPreferences("StepPrefs", Context.MODE_PRIVATE)
                    prefs.edit().putInt("initialSteps_$dayKey", newInitial).apply()

                    val userId = auth.currentUser?.uid ?: return
                    val userStepsRef = database.child("users").child(userId).child("dailySteps").child(dayKey)
                    userStepsRef.child("initialSteps").setValue(newInitial)
                    userStepsRef.child("stepsTaken").setValue(0)

                    stepsTextView.text = "0"
                    updateUI(0)
                    Toast.makeText(this@HealthActivity, "Step counter reset", Toast.LENGTH_SHORT).show()

                    sensorManager?.unregisterListener(this)
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }

            sensorManager?.registerListener(listener, resetSensor, SensorManager.SENSOR_DELAY_NORMAL)
        } else {
            Toast.makeText(this, "Permission not granted to access steps", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onResume()
            } else {
                Toast.makeText(this, "Permission required to track steps", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
