package com.example.fitnesstrack

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnesstrack.databinding.ActivityWorkoutHistoryBinding
import com.google.android.material.snackbar.Snackbar

class WorkoutHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWorkoutHistoryBinding
    private lateinit var workoutAdapter: WorkoutAdapter
    private val workoutList = mutableListOf<Workout>() // Stores completed workouts

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityWorkoutHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Get completed workouts from intent
        val completedWorkouts = intent.getParcelableArrayListExtra<Workout>("completedWorkouts")
        if (!completedWorkouts.isNullOrEmpty()) {
            workoutList.addAll(completedWorkouts)
        } else {
            Toast.makeText(this, "No completed workouts found!", Toast.LENGTH_SHORT).show()
        }

        // Manually add a test workout
        workoutList.add(Workout("Test Workout", "5 reps"))

        // Set up RecyclerView
        setupRecyclerView()

        // Floating Action Button Click - Now opens a dialog to add workout
        binding.fabAddWorkout.setOnClickListener {
            showAddWorkoutDialog()
        }
    }

    private fun setupRecyclerView() {
        workoutAdapter = WorkoutAdapter(
            workoutList,
            onRemoveWorkout = { workout, position ->
                if (position >= 0 && position < workoutList.size) {
                    workoutList.removeAt(position)
                    workoutAdapter.notifyItemRemoved(position)
                    workoutAdapter.notifyItemRangeChanged(position, workoutList.size)
                    Toast.makeText(this, "${workout.name} removed from history", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error: Invalid position", Toast.LENGTH_SHORT).show()
                }
            },
            onEditWorkout = { workout, position ->
                showEditDialog(workout, position)
            },
            onWorkoutCompleted = { workout, position ->
                showCongratulatoryMessage(workout)
                workoutList.removeAt(position)
                workoutAdapter.notifyItemRemoved(position)
                workoutAdapter.notifyItemRangeChanged(position, workoutList.size)
            }
        )

        binding.workoutRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@WorkoutHistoryActivity)
            adapter = workoutAdapter
        }
    }

    private fun showEditDialog(workout: Workout, position: Int) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
        }

        val editTextName = EditText(this).apply {
            setText(workout.name)
            hint = "Workout Name"
        }

        val editTextReps = EditText(this).apply {
            setText(workout.reps)
            hint = "Duration / Reps"
        }

        layout.apply {
            addView(editTextName)
            addView(editTextReps)
        }

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Edit Workout")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val newName = editTextName.text.toString().trim()
                val newReps = editTextReps.text.toString().trim()

                if (newName.isNotEmpty() && newReps.isNotEmpty()) {
                    if (newName != workout.name || newReps != workout.reps) {
                        val updatedWorkout = Workout(newName, newReps)
                        workoutAdapter.updateWorkout(updatedWorkout, position)
                        Toast.makeText(this, "Workout updated", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "No changes made", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    // Show a dialog to ADD a new workout
    private fun showAddWorkoutDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
        }

        val editTextName = EditText(this).apply {
            hint = "Workout Name"
        }

        val editTextReps = EditText(this).apply {
            hint = "Duration / Reps"
        }

        layout.apply {
            addView(editTextName)
            addView(editTextReps)
        }

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Add New Workout")
            .setView(layout)
            .setPositiveButton("Add") { _, _ ->
                val name = editTextName.text.toString().trim()
                val reps = editTextReps.text.toString().trim()

                if (name.isNotEmpty() && reps.isNotEmpty()) {
                    val newWorkout = Workout(name, reps)
                    workoutList.add(newWorkout)
                    workoutAdapter.notifyItemInserted(workoutList.size - 1)
                    Toast.makeText(this, "Workout added", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun showCongratulatoryMessage(workout: Workout) {
        Toast.makeText(this, "Congratulations on completing the ${workout.name} workout!", Toast.LENGTH_LONG).show()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
