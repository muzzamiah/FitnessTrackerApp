package com.example.fitnesstrack



// API Response structure for fetching meals
data class MealResponse(
    val meals: List<Meal> // List of meals returned by the API
)

// Meal for API Response - represents each meal in the API response
data class Meal(
    val id: String,
    val idMeal: String,          // Meal ID from the API
    val strMeal: String,         // Meal name
    val strCategory: String?,    // Meal category (optional)
    val strArea: String?,        // Area or cuisine (optional)
    val strInstructions: String?,// Instructions for the meal (optional)
    val strMealThumb: String?,   // Image URL (optional)
    val strCalories: String?     // Calories (optional)
)


// Local data for UI or User-added meals
data class LocalMeal(
    val name: String,            // Meal name (user-defined)
    val calories: String,        // Calories (user-defined or calculated)
    val idMeal: String,          // Unique ID (optional, can be generated)
    val strMeal: String,         // API meal name (optional, if you fetch data from the API)
    val strMealThumb: String?,   // Image URL from API (optional)
    val strCalories: String?     // Calories (optional)
)

// Helper function to parse calories safely
fun parseCalories(calories: String?): Int {
    return calories?.replace(Regex("[^0-9]"), "")?.toIntOrNull() ?: 0
}

fun main() {
    // Example: Local meals data (user-defined or stored locally)
    val mealList = listOf(
        LocalMeal("Meal 1", "300", "1", "Meal 1 Name", "image_url_1", "300 kcal"),
        LocalMeal("Meal 2", "500", "2", "Meal 2 Name", "image_url_2", "500 kcal"),
        LocalMeal("Meal 3", "200", "3", "Meal 3 Name", "image_url_3", "200 kcal")
    )

    // Convert calories to Int safely before summing up for local meals
    val totalLocalCalories = mealList.sumOf {
        parseCalories(it.calories) // Use the helper function
    }

    println("Total Calories (Local Meals): $totalLocalCalories")

    // Example: API meal data (fetched from TheMealDB API)
    val apiMeal = Meal(
        idMeal = "1",                // ID from the API
        id = "1",                    // Unique ID for the meal
        strMeal = "Spaghetti",       // Meal name from the API
        strCategory = "Pasta",       // Category (optional)
        strArea = "Italian",         // Area (optional)
        strInstructions = "Boil pasta.", // Instructions (optional)
        strMealThumb = "image_url",  // Image URL (optional)
        strCalories = "250 kcal"     // Calories provided
    )

    println("API Meal: $apiMeal")

    // Extract calories from API meal (if available) and calculate the total
    val apiCalories = parseCalories(apiMeal.strCalories)
    println("Total Calories (API Meal): $apiCalories")
}
